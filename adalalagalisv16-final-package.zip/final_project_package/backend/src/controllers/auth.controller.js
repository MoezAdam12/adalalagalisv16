const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { User, Tenant } = require('../models');
const config = require('../config/auth.config');
const appConfig = require('../config/app.config');
const { sanitizeInput, validateEmail, validatePassword } = require('../utils/security.utils');

/**
 * Authentication controller for handling user authentication
 */
class AuthController {
  /**
   * Login user
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async login(req, res) {
    try {
      // Sanitize and validate inputs
      const email = sanitizeInput(req.body.email);
      const password = req.body.password; // Don't sanitize passwords
      const accountNumber = sanitizeInput(req.body.accountNumber);
      
      // Validate required fields
      if (!email || !password || !accountNumber) {
        return res.status(400).json({ 
          message: 'Email, password, and account number are required',
          errors: {
            email: !email ? 'Email is required' : null,
            password: !password ? 'Password is required' : null,
            accountNumber: !accountNumber ? 'Account number is required' : null
          }
        });
      }
      
      // Validate email format
      if (!validateEmail(email)) {
        return res.status(400).json({ 
          message: 'Invalid email format',
          errors: { email: 'Please enter a valid email address' }
        });
      }
      
      // Find tenant by account number
      const tenant = await Tenant.findOne({
        where: { account_number: accountNumber }
      });
      
      if (!tenant) {
        return res.status(404).json({ 
          message: 'Business not found',
          errors: { accountNumber: 'No business found with this account number' }
        });
      }
      
      // Check if tenant is active
      if (tenant.status !== 'active') {
        return res.status(403).json({ 
          message: 'Business account is inactive or suspended',
          errors: { accountNumber: 'This business account is not active' }
        });
      }
      
      // Find user by email within the tenant
      const user = await User.findOne({
        where: { email, tenant_id: tenant.id }
      });
      
      if (!user) {
        return res.status(404).json({ 
          message: 'User not found',
          errors: { email: 'No user found with this email in this business' }
        });
      }
      
      // Check if user is active
      if (user.status !== 'active') {
        return res.status(403).json({ 
          message: 'Account is inactive or suspended',
          errors: { email: 'This user account is not active' }
        });
      }
      
      // Check if account is locked
      if (user.isLocked()) {
        return res.status(403).json({ 
          message: 'Account is temporarily locked due to too many failed login attempts',
          errors: { 
            account: 'Your account is locked. Please try again later or reset your password' 
          },
          lockoutUntil: user.lockout_until
        });
      }
      
      // Verify password
      const passwordIsValid = bcrypt.compareSync(password, user.password_hash);
      if (!passwordIsValid) {
        // Increment login attempts
        await user.incrementLoginAttempts();
        
        // Check if account is now locked after incrementing
        if (user.isLocked()) {
          return res.status(403).json({ 
            message: 'Account is now locked due to too many failed login attempts',
            errors: { 
              account: 'Your account has been locked. Please try again later or reset your password' 
            },
            lockoutUntil: user.lockout_until
          });
        }
        
        return res.status(401).json({ 
          message: 'Invalid password',
          errors: { password: 'The password you entered is incorrect' },
          remainingAttempts: config.maxLoginAttempts - user.login_attempts
        });
      }
      
      // Reset login attempts on successful login
      await user.resetLoginAttempts();
      
      // Generate JWT token
      const token = jwt.sign(
        { 
          id: user.id, 
          email: user.email, 
          tenantId: user.tenant_id, 
          role: user.role,
          accountNumber: tenant.account_number
        },
        config.jwtSecret,
        { expiresIn: config.jwtExpiration }
      );
      
      // Generate refresh token
      const refreshToken = jwt.sign(
        { 
          id: user.id, 
          email: user.email, 
          tenantId: user.tenant_id,
          accountNumber: tenant.account_number
        },
        config.refreshTokenSecret,
        { expiresIn: config.refreshTokenExpiration }
      );
      
      // Update last login timestamp
      await user.update({ last_login: new Date() });
      
      // Return user information and tokens
      res.status(200).json({
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        tenantId: user.tenant_id,
        accountNumber: tenant.account_number,
        businessName: tenant.name,
        language: user.language,
        token,
        refreshToken,
        expiresIn: config.jwtExpiration
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ 
        message: 'An error occurred during login',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Register new user within a tenant
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async register(req, res) {
    try {
      // Sanitize and validate inputs
      const email = sanitizeInput(req.body.email);
      const password = req.body.password; // Don't sanitize passwords
      const firstName = sanitizeInput(req.body.firstName);
      const lastName = sanitizeInput(req.body.lastName);
      const role = sanitizeInput(req.body.role || 'user');
      const accountNumber = sanitizeInput(req.body.accountNumber);
      
      // Validate required fields
      const errors = {};
      if (!email) errors.email = 'Email is required';
      if (!password) errors.password = 'Password is required';
      if (!firstName) errors.firstName = 'First name is required';
      if (!lastName) errors.lastName = 'Last name is required';
      if (!accountNumber) errors.accountNumber = 'Account number is required';
      
      if (Object.keys(errors).length > 0) {
        return res.status(400).json({ 
          message: 'Required fields are missing',
          errors
        });
      }
      
      // Validate email format
      if (!validateEmail(email)) {
        errors.email = 'Please enter a valid email address';
      }
      
      // Validate password strength
      const passwordValidation = validatePassword(password);
      if (!passwordValidation.valid) {
        errors.password = passwordValidation.message;
      }
      
      // Validate role
      const validRoles = ['admin', 'manager', 'lawyer', 'assistant', 'user'];
      if (!validRoles.includes(role)) {
        errors.role = `Role must be one of: ${validRoles.join(', ')}`;
      }
      
      if (Object.keys(errors).length > 0) {
        return res.status(400).json({ 
          message: 'Validation failed',
          errors
        });
      }
      
      // Find tenant by account number
      const tenant = await Tenant.findOne({
        where: { account_number: accountNumber }
      });
      
      if (!tenant) {
        return res.status(404).json({ 
          message: 'Business not found',
          errors: { accountNumber: 'No business found with this account number' }
        });
      }
      
      // Check if tenant is active
      if (tenant.status !== 'active') {
        return res.status(403).json({ 
          message: 'Business account is inactive or suspended',
          errors: { accountNumber: 'This business account is not active' }
        });
      }
      
      // Check if user already exists in this tenant
      const existingUser = await User.findOne({
        where: { email, tenant_id: tenant.id }
      });
      
      if (existingUser) {
        return res.status(400).json({ 
          message: 'User already exists in this business',
          errors: { email: 'A user with this email already exists in this business' }
        });
      }
      
      // Hash password
      const passwordHash = bcrypt.hashSync(password, 10);
      
      // Create new user
      const user = await User.create({
        email,
        password_hash: passwordHash,
        first_name: firstName,
        last_name: lastName,
        role,
        tenant_id: tenant.id,
        language: 'ar', // Default language is Arabic
        status: 'active',
        email_verified: false
      });
      
      // Generate email verification token
      const verificationToken = jwt.sign(
        { id: user.id, email: user.email, tenantId: user.tenant_id },
        config.emailVerificationSecret,
        { expiresIn: config.emailVerificationExpiration }
      );
      
      // In a real application, send verification email
      // For this example, we'll just log it
      console.log(`Verification link: ${appConfig.frontendUrl}/verify-email/${verificationToken}`);
      
      res.status(201).json({
        message: 'User registered successfully',
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          role: user.role,
          accountNumber: tenant.account_number,
          businessName: tenant.name
        }
      });
    } catch (error) {
      console.error('Registration error:', error);
      
      // Handle Sequelize validation errors
      if (error.name === 'SequelizeValidationError') {
        const validationErrors = {};
        error.errors.forEach(err => {
          validationErrors[err.path] = err.message;
        });
        
        return res.status(400).json({ 
          message: 'Validation failed',
          errors: validationErrors
        });
      }
      
      res.status(500).json({ 
        message: 'An error occurred during registration',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Refresh token
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async refreshToken(req, res) {
    try {
      const refreshToken = req.body.refreshToken;
      
      if (!refreshToken) {
        return res.status(400).json({ 
          message: 'Refresh token is required',
          errors: { refreshToken: 'Refresh token is missing' }
        });
      }
      
      // Verify refresh token
      jwt.verify(refreshToken, config.refreshTokenSecret, async (err, decoded) => {
        if (err) {
          return res.status(401).json({ 
            message: 'Invalid or expired refresh token',
            errors: { refreshToken: 'Your session has expired, please log in again' }
          });
        }
        
        try {
          // Find user
          const user = await User.findByPk(decoded.id);
          if (!user) {
            return res.status(404).json({ 
              message: 'User not found',
              errors: { user: 'User no longer exists' }
            });
          }
          
          // Check if user is active
          if (user.status !== 'active') {
            return res.status(403).json({ 
              message: 'Account is inactive or suspended',
              errors: { user: 'This user account is not active' }
            });
          }
          
          // Find tenant
          const tenant = await Tenant.findByPk(user.tenant_id);
          if (!tenant) {
            return res.status(404).json({ 
              message: 'Business not found',
              errors: { business: 'Business no longer exists' }
            });
          }
          
          // Check if tenant is active
          if (tenant.status !== 'active') {
            return res.status(403).json({ 
              message: 'Business account is inactive or suspended',
              errors: { business: 'This business account is not active' }
            });
          }
          
          // Generate new JWT token
          const newToken = jwt.sign(
            { 
              id: user.id, 
              email: user.email, 
              tenantId: user.tenant_id, 
              role: user.role,
              accountNumber: tenant.account_number
            },
            config.jwtSecret,
            { expiresIn: config.jwtExpiration }
          );
          
          // Generate new refresh token
          const newRefreshToken = jwt.sign(
            { 
              id: user.id, 
              email: user.email, 
              tenantId: user.tenant_id,
              accountNumber: tenant.account_number
            },
            config.refreshTokenSecret,
            { expiresIn: config.refreshTokenExpiration }
          );
          
          res.status(200).json({
            token: newToken,
            refreshToken: newRefreshToken,
            expiresIn: config.jwtExpiration
          });
        } catch (error) {
          console.error('Token refresh error:', error);
          res.status(500).json({ 
            message: 'An error occurred during token refresh',
            errors: { server: 'Internal server error, please try again later' }
          });
        }
      });
    } catch (error) {
      console.error('Refresh token error:', error);
      res.status(500).json({ 
        message: 'An error occurred during token refresh',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Logout user
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async logout(req, res) {
    try {
      // In a stateless JWT authentication system, the client is responsible for
      // discarding the token. The server doesn't need to do anything.
      
      // However, we can log the logout event if needed
      if (req.userId) {
        const user = await User.findByPk(req.userId);
        if (user) {
          console.log(`User ${user.email} logged out at ${new Date()}`);
        }
      }
      
      res.status(200).json({ message: 'Logout successful' });
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({ 
        message: 'An error occurred during logout',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Forgot password
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async forgotPassword(req, res) {
    try {
      // Sanitize and validate inputs
      const email = sanitizeInput(req.body.email);
      const accountNumber = sanitizeInput(req.body.accountNumber);
      
      // Validate required fields
      if (!email || !accountNumber) {
        return res.status(400).json({ 
          message: 'Email and account number are required',
          errors: {
            email: !email ? 'Email is required' : null,
            accountNumber: !accountNumber ? 'Account number is required' : null
          }
        });
      }
      
      // Validate email format
      if (!validateEmail(email)) {
        return res.status(400).json({ 
          message: 'Invalid email format',
          errors: { email: 'Please enter a valid email address' }
        });
      }
      
      // Find tenant by account number
      const tenant = await Tenant.findOne({
        where: { account_number: accountNumber }
      });
      
      if (!tenant) {
        // For security reasons, don't reveal that the tenant doesn't exist
        return res.status(200).json({ 
          message: 'If your email is registered, you will receive a password reset link'
        });
      }
      
      // Find user by email within the tenant
      const user = await User.findOne({
        where: { email, tenant_id: tenant.id }
      });
      
      if (!user) {
        // For security reasons, don't reveal that the user doesn't exist
        return res.status(200).json({ 
          message: 'If your email is registered, you will receive a password reset link'
        });
      }
      
      // Generate password reset token
      const resetToken = jwt.sign(
        { id: user.id, email: user.email, tenantId: user.tenant_id },
        config.resetTokenSecret,
        { expiresIn: config.resetTokenExpiration }
      );
      
      // In a real application, send an email with the reset link
      // For this example, we'll just log it
      console.log(`Password reset link: ${appConfig.frontendUrl}/reset-password/${resetToken}`);
      
      res.status(200).json({
        message: 'If your email is registered, you will receive a password reset link',
        // In production, this would be sent via email, not in the response
        resetToken: process.env.NODE_ENV === 'production' ? undefined : resetToken
      });
    } catch (error) {
      console.error('Forgot password error:', error);
      res.status(500).json({ 
        message: 'An error occurred during password reset request',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Reset password
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async resetPassword(req, res) {
    try {
      const token = sanitizeInput(req.params.token);
      const password = req.body.password; // Don't sanitize passwords
      
      if (!token || !password) {
        return res.status(400).json({ 
          message: 'Token and new password are required',
          errors: {
            token: !token ? 'Reset token is required' : null,
            password: !password ? 'New password is required' : null
          }
        });
      }
      
      // Validate password strength
      const passwordValidation = validatePassword(password);
      if (!passwordValidation.valid) {
        return res.status(400).json({ 
          message: 'Password validation failed',
          errors: { password: passwordValidation.message }
        });
      }
      
      // Verify reset token
      jwt.verify(token, config.resetTokenSecret, async (err, decoded) => {
        if (err) {
          return res.status(401).json({ 
            message: 'Invalid or expired reset token',
            errors: { token: 'Your password reset link has expired or is invalid' }
          });
        }
        
        try {
          // Find user
          const user = await User.findByPk(decoded.id);
          if (!user) {
            return res.status(404).json({ 
              message: 'User not found',
              errors: { user: 'User no longer exists' }
            });
          }
          
          // Hash new password
          const passwordHash = bcrypt.hashSync(password, 10);
          
          // Update user password and reset login attempts
          await user.update({ 
            password_hash: passwordHash,
            login_attempts: 0,
            lockout_until: null
          });
          
          res.status(200).json({ message: 'Password reset successful' });
        } catch (error) {
          console.error('Reset password error:', error);
          res.status(500).json({ 
            message: 'An error occurred during password reset',
            errors: { server: 'Internal server error, please try again later' }
          });
        }
      });
    } catch (error) {
      console.error('Reset password error:', error);
      res.status(500).json({ 
        message: 'An error occurred during password reset',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Verify email
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async verifyEmail(req, res) {
    try {
      const token = sanitizeInput(req.params.token);
      
      if (!token) {
        return res.status(400).json({ 
          message: 'Verification token is required',
          errors: { token: 'Email verification token is missing' }
        });
      }
      
      // Verify email verification token
      jwt.verify(token, config.emailVerificationSecret, async (err, decoded) => {
        if (err) {
          return res.status(401).json({ 
            message: 'Invalid or expired verification token',
            errors: { token: 'Your email verification link has expired or is invalid' }
          });
        }
        
        try {
          // Find user
          const user = await User.findByPk(decoded.id);
          if (!user) {
            return res.status(404).json({ 
              message: 'User not found',
              errors: { user: 'User no longer exists' }
            });
          }
          
          // Update user email verification status
          await user.update({ email_verified: true });
          
          res.status(200).json({ message: 'Email verified successfully' });
        } catch (error) {
          console.error('Email verification error:', error);
          res.status(500).json({ 
            message: 'An error occurred during email verification',
            errors: { server: 'Internal server error, please try again later' }
          });
        }
      });
    } catch (error) {
      console.error('Email verification error:', error);
      res.status(500).json({ 
        message: 'An error occurred during email verification',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
  
  /**
   * Get current user profile
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async getCurrentUser(req, res) {
    try {
      // User ID should be available from the JWT token verification middleware
      const userId = req.userId;
      
      if (!userId) {
        return res.status(401).json({ 
          message: 'Not authenticated',
          errors: { auth: 'You must be logged in to access this resource' }
        });
      }
      
      // Find user with tenant information
      const user = await User.findByPk(userId, {
        attributes: [
          'id', 'email', 'first_name', 'last_name', 'role', 
          'tenant_id', 'language', 'status', 'last_login', 
          'profile_image_url', 'email_verified', 'settings'
        ],
        include: [{
          model: Tenant,
          as: 'tenant',
          attributes: ['id', 'name', 'account_number', 'subscription_plan', 'logo_url']
        }]
      });
      
      if (!user) {
        return res.status(404).json({ 
          message: 'User not found',
          errors: { user: 'User no longer exists' }
        });
      }
      
      res.status(200).json({
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        tenantId: user.tenant_id,
        language: user.language,
        status: user.status,
        lastLogin: user.last_login,
        profileImageUrl: user.profile_image_url,
        emailVerified: user.email_verified,
        settings: user.settings,
        business: user.tenant ? {
          id: user.tenant.id,
          name: user.tenant.name,
          accountNumber: user.tenant.account_number,
          subscriptionPlan: user.tenant.subscription_plan,
          logoUrl: user.tenant.logo_url
        } : null
      });
    } catch (error) {
      console.error('Get current user error:', error);
      res.status(500).json({ 
        message: 'An error occurred while fetching user profile',
        errors: { server: 'Internal server error, please try again later' }
      });
    }
  }
}

module.exports = new AuthController();
