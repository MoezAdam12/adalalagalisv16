const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

/**
 * AuditLog model for tracking all actions and changes in the system
 */
class AuditLog extends Model {}

AuditLog.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  tenant_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'tenant_management.tenants',
      key: 'id'
    }
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'user_management.users',
      key: 'id'
    }
  },
  action: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      isIn: {
        args: [['CREATE', 'READ', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'EXPORT', 'IMPORT', 'SYNC', 'TEST', 'APPROVE', 'REJECT', 'SEND', 'DOWNLOAD', 'UPLOAD', 'CONFIGURE', 'ENABLE', 'DISABLE', 'OTHER']],
        msg: 'Invalid action type'
      }
    }
  },
  entity_type: {
    type: DataTypes.STRING,
    allowNull: false
  },
  entity_id: {
    type: DataTypes.UUID,
    allowNull: true
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  ip_address: {
    type: DataTypes.STRING,
    allowNull: true
  },
  user_agent: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  old_values: {
    type: DataTypes.JSONB,
    allowNull: true
  },
  new_values: {
    type: DataTypes.JSONB,
    allowNull: true
  },
  metadata: {
    type: DataTypes.JSONB,
    allowNull: true
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true,
    validate: {
      isIn: {
        args: [['SUCCESS', 'FAILURE', 'WARNING', 'INFO']],
        msg: 'Invalid status'
      }
    },
    defaultValue: 'SUCCESS'
  },
  severity: {
    type: DataTypes.STRING,
    allowNull: true,
    validate: {
      isIn: {
        args: [['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']],
        msg: 'Invalid severity'
      }
    },
    defaultValue: 'LOW'
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  sequelize,
  modelName: 'audit_log',
  tableName: 'settings.audit_logs',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  indexes: [
    {
      fields: ['tenant_id'],
      name: 'audit_logs_tenant_id_idx'
    },
    {
      fields: ['user_id'],
      name: 'audit_logs_user_id_idx'
    },
    {
      fields: ['action'],
      name: 'audit_logs_action_idx'
    },
    {
      fields: ['entity_type', 'entity_id'],
      name: 'audit_logs_entity_idx'
    },
    {
      fields: ['created_at'],
      name: 'audit_logs_created_at_idx'
    },
    {
      fields: ['status'],
      name: 'audit_logs_status_idx'
    },
    {
      fields: ['severity'],
      name: 'audit_logs_severity_idx'
    }
  ]
});

module.exports = AuditLog;
