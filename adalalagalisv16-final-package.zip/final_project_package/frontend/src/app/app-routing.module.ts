import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { RoleGuard } from './core/guards/role.guard';
import { AdminDashboardComponent } from './features/admin-dashboard/components/dashboard-home/dashboard-home.component';
import { BusinessManagementComponent } from './features/admin-dashboard/components/business-management/business-management.component';
import { BusinessFormComponent } from './features/admin-dashboard/components/business-form/business-form.component';
import { LoginComponent } from './features/auth/components/login/login.component';
import { LandingPageComponent } from './features/landing/landing-page.component';
import { UserListComponent } from './features/admin/components/user-list/user-list.component';
import { UserFormComponent } from './features/admin/components/user-form/user-form.component';
import { RoleListComponent } from './features/admin/components/role-list/role-list.component';
import { RoleFormComponent } from './features/admin/components/role-form/role-form.component';
import { SubscriptionManagementComponent } from './features/admin/components/subscription-management/subscription-management.component';
import { EmailSettingsComponent } from './features/admin/components/email-settings/email-settings.component';
import { NotificationSettingsComponent } from './features/admin/components/notification-settings/notification-settings.component';
import { UiThemeSettingsComponent } from './features/admin/components/ui-theme-settings/ui-theme-settings.component';
import { SecuritySettingsComponent } from './features/admin/components/security-settings/security-settings.component';
import { IntegrationsListComponent } from './features/admin/components/integrations-list/integrations-list.component';
import { IntegrationFormComponent } from './features/admin/components/integration-form/integration-form.component';
import { AuditLogsComponent } from './features/admin/components/audit-logs/audit-logs.component';
import { EmailTemplatesListComponent } from './features/admin/components/email-templates-list/email-templates-list.component';
import { EmailTemplateFormComponent } from './features/admin/components/email-template-form/email-template-form.component';
import { LanguagesListComponent } from './features/admin/components/languages-list/languages-list.component';
import { LanguageFormComponent } from './features/admin/components/language-form/language-form.component';

const routes: Routes = [
  { path: '', component: LandingPageComponent },
  { path: 'login', component: LoginComponent },
  { 
    path: 'admin', 
    canActivate: [AuthGuard, RoleGuard], 
    data: { roles: ['admin'] },
    children: [
      { path: '', component: AdminDashboardComponent },
      { path: 'businesses', component: BusinessManagementComponent },
      { path: 'businesses/new', component: BusinessFormComponent },
      { path: 'businesses/:id', component: BusinessFormComponent },
      { path: 'users', component: UserListComponent },
      { path: 'users/new', component: UserFormComponent },
      { path: 'users/:id', component: UserFormComponent },
      { path: 'roles', component: RoleListComponent },
      { path: 'roles/new', component: RoleFormComponent },
      { path: 'roles/:id', component: RoleFormComponent },
      { path: 'subscriptions', component: SubscriptionManagementComponent },
      { path: 'email-settings', component: EmailSettingsComponent },
      { path: 'notification-settings', component: NotificationSettingsComponent },
      { path: 'ui-settings', component: UiThemeSettingsComponent },
      { path: 'security-settings', component: SecuritySettingsComponent },
      { path: 'integrations', component: IntegrationsListComponent },
      { path: 'integrations/new', component: IntegrationFormComponent },
      { path: 'integrations/:id', component: IntegrationFormComponent },
      { path: 'audit-logs', component: AuditLogsComponent },
      { path: 'email-templates', component: EmailTemplatesListComponent },
      { path: 'email-templates/new', component: EmailTemplateFormComponent },
      { path: 'email-templates/:id', component: EmailTemplateFormComponent },
      { path: 'languages', component: LanguagesListComponent },
      { path: 'languages/new', component: LanguageFormComponent },
      { path: 'languages/:id', component: LanguageFormComponent }
    ]
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
