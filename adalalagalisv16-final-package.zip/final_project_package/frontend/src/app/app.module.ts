import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DragDropModule } from '@angular/cdk/drag-drop';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthInterceptor } from './core/interceptors/auth.interceptor';
import { ErrorInterceptor } from './core/interceptors/error.interceptor';
import { AdminDashboardComponent } from './features/admin-dashboard/components/dashboard-home/dashboard-home.component';
import { BusinessManagementComponent } from './features/admin-dashboard/components/business-management/business-management.component';
import { BusinessFormComponent } from './features/admin-dashboard/components/business-form/business-form.component';
import { LoginComponent } from './features/auth/components/login/login.component';
import { LandingPageComponent } from './features/landing/landing-page.component';
import { UserListComponent } from './features/admin/components/user-list/user-list.component';
import { UserFormComponent } from './features/admin/components/user-form/user-form.component';
import { RoleListComponent } from './features/admin/components/role-list/role-list.component';
import { RoleFormComponent } from './features/admin/components/role-form/role-form.component';
import { SubscriptionManagementComponent } from './features/admin/components/subscription-management/subscription-management.component';
import { EmailSettingsComponent } from './features/admin/components/email-settings/email-settings.component';
import { NotificationSettingsComponent } from './features/admin/components/notification-settings/notification-settings.component';
import { UiThemeSettingsComponent } from './features/admin/components/ui-theme-settings/ui-theme-settings.component';
import { SecuritySettingsComponent } from './features/admin/components/security-settings/security-settings.component';
import { IntegrationsListComponent } from './features/admin/components/integrations-list/integrations-list.component';
import { IntegrationFormComponent } from './features/admin/components/integration-form/integration-form.component';
import { AuditLogsComponent } from './features/admin/components/audit-logs/audit-logs.component';
import { EmailTemplatesListComponent } from './features/admin/components/email-templates-list/email-templates-list.component';
import { EmailTemplateFormComponent } from './features/admin/components/email-template-form/email-template-form.component';
import { LanguagesListComponent } from './features/admin/components/languages-list/languages-list.component';
import { LanguageFormComponent } from './features/admin/components/language-form/language-form.component';
import { AdminSidebarComponent } from './features/admin/components/admin-sidebar/admin-sidebar.component';
import { AdminHeaderComponent } from './features/admin/components/admin-header/admin-header.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminDashboardComponent,
    BusinessManagementComponent,
    BusinessFormComponent,
    LoginComponent,
    LandingPageComponent,
    UserListComponent,
    UserFormComponent,
    RoleListComponent,
    RoleFormComponent,
    SubscriptionManagementComponent,
    EmailSettingsComponent,
    NotificationSettingsComponent,
    UiThemeSettingsComponent,
    SecuritySettingsComponent,
    IntegrationsListComponent,
    IntegrationFormComponent,
    AuditLogsComponent,
    EmailTemplatesListComponent,
    EmailTemplateFormComponent,
    LanguagesListComponent,
    LanguageFormComponent,
    AdminSidebarComponent,
    AdminHeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    DragDropModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
