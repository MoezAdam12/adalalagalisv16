import { Component, OnInit } from '@angular/core';
import { BillingService } from '../../services/billing.service';
import { NotificationService } from '../../../../core/services/notification.service';

@Component({
  selector: 'app-subscription-management',
  templateUrl: './subscription-management.component.html',
  styleUrls: ['./subscription-management.component.scss']
})
export class SubscriptionManagementComponent implements OnInit {
  subscriptionTiers: any[] = [];
  currentSubscription: any = null;
  subscriptionHistory: any[] = [];
  loading = {
    tiers: false,
    subscription: false,
    history: false
  };
  error = {
    tiers: '',
    subscription: '',
    history: ''
  };
  
  constructor(
    private billingService: BillingService,
    private notificationService: NotificationService
  ) { }

  ngOnInit(): void {
    this.loadSubscriptionTiers();
    this.loadCurrentSubscription();
    this.loadSubscriptionHistory();
  }

  loadSubscriptionTiers(): void {
    this.loading.tiers = true;
    this.error.tiers = '';
    
    this.billingService.getSubscriptionTiers().subscribe(
      (response) => {
        if (response && response.data) {
          this.subscriptionTiers = response.data;
        }
        this.loading.tiers = false;
      },
      (error) => {
        console.error('Failed to load subscription tiers:', error);
        this.error.tiers = 'فشل في تحميل باقات الاشتراك. يرجى المحاولة مرة أخرى.';
        this.loading.tiers = false;
      }
    );
  }

  loadCurrentSubscription(): void {
    this.loading.subscription = true;
    this.error.subscription = '';
    
    this.billingService.getTenantSubscription().subscribe(
      (response) => {
        if (response && response.data) {
          this.currentSubscription = response.data;
        }
        this.loading.subscription = false;
      },
      (error) => {
        if (error.status === 404) {
          // No active subscription, this is not an error
          this.currentSubscription = null;
        } else {
          console.error('Failed to load current subscription:', error);
          this.error.subscription = 'فشل في تحميل الاشتراك الحالي. يرجى المحاولة مرة أخرى.';
        }
        this.loading.subscription = false;
      }
    );
  }

  loadSubscriptionHistory(): void {
    this.loading.history = true;
    this.error.history = '';
    
    this.billingService.getTenantSubscriptionHistory().subscribe(
      (response) => {
        if (response && response.data) {
          this.subscriptionHistory = response.data;
        }
        this.loading.history = false;
      },
      (error) => {
        console.error('Failed to load subscription history:', error);
        this.error.history = 'فشل في تحميل سجل الاشتراكات. يرجى المحاولة مرة أخرى.';
        this.loading.history = false;
      }
    );
  }

  subscribeToPlan(tierId: string, billingCycle: string): void {
    if (!confirm('هل أنت متأكد من الاشتراك في هذه الباقة؟')) {
      return;
    }
    
    const subscriptionData = {
      tier_id: tierId,
      billing_cycle: billingCycle,
      auto_renew: true
    };
    
    this.billingService.subscribeTenant(subscriptionData).subscribe(
      (response) => {
        // Show notification
        this.notificationService.createNotification({
          user_id: 'current',
          title: 'تم الاشتراك بنجاح',
          message: 'تم الاشتراك في الباقة بنجاح',
          type: 'success',
          category: 'billing'
        }).subscribe();
        
        // Reload subscription data
        this.loadCurrentSubscription();
        this.loadSubscriptionHistory();
      },
      (error) => {
        console.error('Failed to subscribe to plan:', error);
        
        // Show error notification
        this.notificationService.createNotification({
          user_id: 'current',
          title: 'فشل الاشتراك',
          message: error.message || 'فشل في الاشتراك في الباقة. يرجى المحاولة مرة أخرى.',
          type: 'error',
          category: 'billing'
        }).subscribe();
      }
    );
  }

  cancelSubscription(): void {
    if (!this.currentSubscription) {
      return;
    }
    
    if (!confirm('هل أنت متأكد من إلغاء الاشتراك الحالي؟')) {
      return;
    }
    
    const reason = prompt('يرجى ذكر سبب إلغاء الاشتراك (اختياري)');
    
    const cancelData = {
      subscription_id: this.currentSubscription.id,
      cancellation_reason: reason || 'لم يتم تحديد سبب'
    };
    
    this.billingService.cancelSubscription(cancelData).subscribe(
      (response) => {
        // Show notification
        this.notificationService.createNotification({
          user_id: 'current',
          title: 'تم إلغاء الاشتراك',
          message: 'تم إلغاء الاشتراك بنجاح',
          type: 'info',
          category: 'billing'
        }).subscribe();
        
        // Reload subscription data
        this.loadCurrentSubscription();
        this.loadSubscriptionHistory();
      },
      (error) => {
        console.error('Failed to cancel subscription:', error);
        
        // Show error notification
        this.notificationService.createNotification({
          user_id: 'current',
          title: 'فشل إلغاء الاشتراك',
          message: error.message || 'فشل في إلغاء الاشتراك. يرجى المحاولة مرة أخرى.',
          type: 'error',
          category: 'billing'
        }).subscribe();
      }
    );
  }

  getSubscriptionStatusClass(status: string): string {
    switch (status) {
      case 'active':
        return 'badge bg-success';
      case 'trial':
        return 'badge bg-info';
      case 'canceled':
        return 'badge bg-warning';
      case 'expired':
        return 'badge bg-secondary';
      case 'past_due':
        return 'badge bg-danger';
      case 'unpaid':
        return 'badge bg-danger';
      default:
        return 'badge bg-secondary';
    }
  }

  getSubscriptionStatusText(status: string): string {
    switch (status) {
      case 'active':
        return 'نشط';
      case 'trial':
        return 'تجريبي';
      case 'canceled':
        return 'ملغي';
      case 'expired':
        return 'منتهي';
      case 'past_due':
        return 'متأخر الدفع';
      case 'unpaid':
        return 'غير مدفوع';
      default:
        return status;
    }
  }

  getBillingCycleText(cycle: string): string {
    return cycle === 'monthly' ? 'شهري' : 'سنوي';
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('ar-SA');
  }

  getRemainingDays(endDate: string): number {
    const end = new Date(endDate);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }
}
